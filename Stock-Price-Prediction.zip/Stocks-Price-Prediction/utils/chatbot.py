import json
import re
from datetime import datetime
try:
    from utils.data_utils import StockDataFetcher
except Exception:
    # fallback if module import context differs
    from data_utils import StockDataFetcher

class StockChatbot:
    """Simple chatbot for stock-related queries"""
    
    def __init__(self):
        self.responses = self._initialize_responses()
    
    def _initialize_responses(self):
        """Initialize chatbot responses"""
        return {

        # ---------------- BASIC ----------------
        'greeting': {
            'keywords': ['hello', 'hi', 'hey', 'greetings'],
            'response': "Hello 👋 Welcome to the Stock Price Prediction system. How can I help you today?"
        },

        'help': {
            'keywords': ['help', 'assist', 'guide', 'support'],
            'response': (
                "I can help you with:\n"
                "- Stock price prediction\n"
                "- Machine learning models\n"
                "- Accuracy & evaluation metrics\n"
                "- Downloading stock data\n"
                "- Project features & usage\n"
                "- FAQs and troubleshooting"
            )
        },

        # ---------------- PROJECT ----------------
        'tell me about project': {
            'keywords': ['project', 'about', 'system', 'application'],
            'response': (
                "This is a Stock Price Prediction system that uses Machine Learning models "
                "to forecast future stock prices. It allows users to analyze stocks, "
                "compare models, visualize predictions, and download historical data."
            )
        },

        'how_to_use': {
            'keywords': ['how to use', 'steps', 'procedure', 'workflow'],
            'response': (
                "How to use the system:\n"
                "1. Login or Signup\n"
                "2. Go to Dashboard\n"
                "3. Click 'Start Prediction'\n"
                "4. Select stock & days (1–30)\n"
                "5. Click Predict\n"
                "6. View charts and results"
            )
        },

        # ---------------- MODELS ----------------
        'models_used': {
            'keywords': ['model', 'models', 'algorithm', 'lstm', 'regression', 'forest', 'arima'],
            'response': (
                "We use multiple prediction models:\n"
                "1. LSTM – Deep learning model for time-series data\n"
                "2. Linear Regression – Trend-based prediction\n"
                "3. Random Forest – Ensemble machine learning model\n"
                "4. ARIMA – Statistical forecasting model\n"
                "Comparing models improves reliability."
            )
        },

        'why_multiple_models': {
            'keywords': ['why many models', 'compare models', 'multiple models'],
            'response': (
                "Using multiple models helps:\n"
                "- Reduce prediction bias\n"
                "- Compare accuracy\n"
                "- Handle different market behaviors\n"
                "- Improve decision making"
            )
        },

        # ---------------- PREDICTION ----------------
        'prediction': {
            'keywords': ['predict', 'forecast', 'future price'],
            'response': (
                "Stock prediction uses historical price data and machine learning "
                "models to estimate future prices. You can predict prices for 1 to 30 days."
            )
        },

        'prediction_days': {
            'keywords': ['days', 'how many days', '30 days', 'range'],
            'response': "You can predict stock prices from **1 to 30 days** ahead."
        },

        # ---------------- ACCURACY ----------------
        'accuracy': {
            'keywords': ['accuracy', 'accurate', 'reliable'],
            'response': (
                "Prediction accuracy depends on:\n"
                "- Market volatility\n"
                "- Quality of historical data\n"
                "- Model used\n\n"
                "We evaluate models using:\n"
                "- RMSE (Root Mean Square Error)\n"
                "- MAE (Mean Absolute Error)"
            )
        },

        'guarantee': {
            'keywords': ['guarantee', 'sure', '100%', 'profit'],
            'response': (
                "⚠️ No model can guarantee 100% accuracy. "
                "Stock markets are influenced by real-world events, news, and investor behavior."
            )
        },

        # ---------------- DATA ----------------
        'data_source': {
            'keywords': ['data source', 'where data', 'api'],
            'response': (
                "Stock data is fetched from reliable public APIs like Yahoo Finance, "
                "which provide historical and recent market data."
            )
        },

        'download_data': {
            'keywords': ['download', 'export', 'csv', 'historical'],
            'response': (
                "You can download historical stock data in CSV format. "
                "Select any stock and choose a date range from days to years."
            )
        },

        # ---------------- CHARTS ----------------
        'charts': {
            'keywords': ['chart', 'graph', 'visual', 'plot'],
            'response': (
                "The system displays:\n"
                "- Actual vs predicted price charts\n"
                "- Model comparison graphs\n"
                "- Trend visualization\n"
                "Charts help understand prediction behavior clearly."
            )
        },

        # ---------------- RISKS ----------------
        'risk': {
            'keywords': ['risk', 'loss', 'safe'],
            'response': (
                "Stock trading involves risk. Predictions are for educational "
                "and analytical purposes only and should not be treated as financial advice."
            )
        },

        # ---------------- CHATBOT ----------------
        'chatbot': {
            'keywords': ['chatbot', 'assistant', 'ai help'],
            'response': (
                "I am an AI-based assistant designed to help users "
                "understand stock predictions, models, data, and system features."
            )
        },

        # ---------------- ACCOUNT ----------------
        'account': {
            'keywords': ['login', 'signup', 'account', 'password'],
            'response': (
                "User accounts allow secure login, saved preferences, "
                "and personalized access to predictions and downloads."
            )
        },

        # ---------------- FAQ ----------------
        'faq': {
            'keywords': ['faq', 'questions', 'common doubts'],
            'response': (
                "FAQs cover:\n"
                "- How predictions work\n"
                "- Accuracy metrics\n"
                "- Data usage\n"
                "- System limitations"
            )
        },

        # ---------------- DEFAULT ----------------
        'default': {
            'keywords': [],
            'response': (
                "I'm here to help 😊 Ask me about stock predictions, models, "
                "accuracy, data downloads, or project features."
            )
        }
    }
    
    def get_response(self, user_input):
        """Get chatbot response based on user input"""
        user_input = user_input.lower().strip()
        # Price lookup pattern: e.g., "price of AAPL" or "current price AAPL"
        m = re.search(r"price(?: of| for)?\s+([A-Za-z\.\-]+)", user_input)
        if m:
            symbol = m.group(1).upper()
            try:
                # Try fetching latest close price (may use demo fallback)
                df = StockDataFetcher.fetch_stock_data(symbol, days=7, retries=2)
                if df is not None and not df.empty:
                    close_vals = StockDataFetcher.get_closing_prices(df)
                    latest = float(close_vals[-1])
                    return f"Current price for {symbol} is ${latest:,.2f} (source: latest available data)."
                else:
                    return f"I couldn't fetch data for {symbol} right now. Try again later or check the stock symbol."
            except Exception as e:
                return f"Error fetching price for {symbol}: {str(e)}"

        # Find best matching canned response
        for key, data in self.responses.items():
            if key == 'default':
                continue

            for keyword in data['keywords']:
                if keyword in user_input:
                    return data['response']

        # Return default response if no match
        return self.responses['default']['response']
    
    def get_quick_tips(self):
        """Get quick tips for users"""
        tips = [
            "📊 Compare all 4 models to get the best prediction insights",
            "📈 RMSE and MAE metrics help you understand model accuracy",
            "📥 Download historical data to analyze trends yourself",
            "🔄 Check predictions regularly as markets change daily",
            "🌙 Use dark mode for comfortable viewing at night",
            "💾 Export charts as images or PDFs for reports"
        ]
        return tips
